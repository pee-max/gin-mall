create definer = root@localhost view s_sc_c as
select `s`.`Sno` AS `xh`, `s`.`Sname` AS `xm`, `c`.`Cno` AS `kch`, `c`.`Cname` AS `kcm`, `study`.`sc`.`Grade` AS `cj`
from ((`study`.`student` `s` join `study`.`course` `c`) join `study`.`sc`)
where ((`s`.`Sno` = `study`.`sc`.`Sno`) and (`c`.`Cno` = `study`.`sc`.`Cno`));

