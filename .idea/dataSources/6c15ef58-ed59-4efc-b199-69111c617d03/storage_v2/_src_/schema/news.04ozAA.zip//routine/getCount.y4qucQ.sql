create
    definer = root@localhost procedure getCount(IN nid int, OUT cCount int)
BEGIN
    SELECT COUNT(*) INTO cCount FROM comment WHERE Comm_NewsID = nid;
    UPDATE newsinfo SET commCount = cCount WHERE NewsID = nid;
END;

