create definer = root@localhost view pinglun as
select `u`.`UserAccount` AS `UserAccount`,
       `u`.`NickName`    AS `NickName`,
       `c`.`CommContent` AS `CommContent`,
       `c`.`CommTime`    AS `CommTime`,
       `n`.`NewsTitle`   AS `NewsTitle`
from `news`.`userinfo` `u`
         join `news`.`comment` `c`
         join `news`.`newsinfo` `n`
where ((`u`.`UserID` = `c`.`Comm_UserID`) and (`c`.`Comm_NewsID` = `n`.`NewsID`));

