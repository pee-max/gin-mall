create definer = root@localhost trigger tr_update_commcount
    after insert
    on comment
    for each row
BEGIN
    CALL getCount(NEW.Comm_NewsID, @dummy);
END;

