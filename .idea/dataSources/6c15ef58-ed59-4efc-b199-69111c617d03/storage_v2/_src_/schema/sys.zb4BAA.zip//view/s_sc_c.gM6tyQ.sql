create definer = root@localhost view s_sc_c as
select `s`.`Sno` AS `xh`, `s`.`Sname` AS `xm`, `c`.`Cno` AS `kch`, `c`.`Cname` AS `kcm`, `sys`.`sc`.`Grade` AS `cj`
from ((`sys`.`student` `s` join `sys`.`course` `c`) join `sys`.`sc`)
where ((`s`.`Sno` = `sys`.`sc`.`Sno`) and (`c`.`Cno` = `sys`.`sc`.`Cno`));

