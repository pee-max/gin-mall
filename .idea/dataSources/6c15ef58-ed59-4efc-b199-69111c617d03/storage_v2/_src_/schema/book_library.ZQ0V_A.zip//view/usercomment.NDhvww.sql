create definer = root@localhost view usercomment as
select `book_library`.`bookinfo`.`ISBN`     AS `ISBN`,
       `book_library`.`bookinfo`.`BookName` AS `BookName`,
       `book_library`.`userinfo`.`UserName` AS `UserName`,
       `comm`.`tcontent`                    AS `tcontent`,
       `comm`.`ttime`                       AS `ttime`,
       `comm`.`thits`                       AS `thits`,
       `comm`.`fcontent`                    AS `fcontent`
from ((`book_library`.`userinfo` join `book_library`.`bookinfo`) join (select `t1`.`Comm_ISBN`   AS `tISBN`,
                                                                              `t1`.`Comm_UserID` AS `tuser`,
                                                                              `t1`.`CommContent` AS `tcontent`,
                                                                              `t1`.`CommTime`    AS `ttime`,
                                                                              `t1`.`CommHits`    AS `thits`,
                                                                              `t2`.`CommContent` AS `fcontent`
                                                                       from (`book_library`.`comment` `t1` left join `book_library`.`comment` `t2`
                                                                             on ((`t1`.`ParentCommID` = `t2`.`CommID`)))) `comm`)
where ((`book_library`.`userinfo`.`UserID` = `comm`.`tuser`) and (`book_library`.`bookinfo`.`ISBN` = `comm`.`tISBN`))
order by `book_library`.`bookinfo`.`ISBN`, `comm`.`ttime`, `book_library`.`userinfo`.`UserID`;

-- comment on column usercomment.ISBN not supported: 图书编号

-- comment on column usercomment.BookName not supported: 图书名称

-- comment on column usercomment.UserName not supported: 用户名

-- comment on column usercomment.tcontent not supported: 评论内容

-- comment on column usercomment.ttime not supported: 评论时间

-- comment on column usercomment.thits not supported: 点赞数

-- comment on column usercomment.fcontent not supported: 评论内容

