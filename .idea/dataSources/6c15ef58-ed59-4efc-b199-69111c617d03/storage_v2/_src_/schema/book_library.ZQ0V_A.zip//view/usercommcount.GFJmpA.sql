create definer = root@localhost view usercommcount as
select `book_library`.`userinfo`.`UserID`   AS `UserID`,
       `book_library`.`userinfo`.`UserName` AS `UserName`,
       count(0)                             AS `count(*)`
from (`book_library`.`userinfo` join `book_library`.`comment`)
where (`book_library`.`userinfo`.`UserID` = `book_library`.`comment`.`Comm_UserID`)
group by `book_library`.`comment`.`Comm_UserID`;

-- comment on column usercommcount.UserID not supported: 用户编号

-- comment on column usercommcount.UserName not supported: 用户名

