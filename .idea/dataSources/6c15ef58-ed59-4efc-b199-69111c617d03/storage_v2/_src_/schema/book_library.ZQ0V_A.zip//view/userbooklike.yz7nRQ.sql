create definer = root@localhost view userbooklike as
select `book_library`.`userinfo`.`UserID`   AS `UserID`,
       `book_library`.`userinfo`.`UserName` AS `UserName`,
       count(0)                             AS `count(*)`
from (`book_library`.`userinfo` join `book_library`.`booklike`)
where (`book_library`.`userinfo`.`UserID` = `book_library`.`booklike`.`LikeUserID`)
group by `book_library`.`booklike`.`LikeUserID`;

-- comment on column userbooklike.UserID not supported: 用户编号

-- comment on column userbooklike.UserName not supported: 用户名

