create definer = root@localhost view s_sc_c as
select `s`.`Sno` AS `xh`, `s`.`Sname` AS `xm`, `c`.`Cno` AS `kch`, `c`.`Cname` AS `kcm`, `world`.`sc`.`Grade` AS `cj`
from ((`world`.`student` `s` join `world`.`course` `c`) join `world`.`sc`)
where ((`s`.`Sno` = `world`.`sc`.`Sno`) and (`c`.`Cno` = `world`.`sc`.`Cno`));

