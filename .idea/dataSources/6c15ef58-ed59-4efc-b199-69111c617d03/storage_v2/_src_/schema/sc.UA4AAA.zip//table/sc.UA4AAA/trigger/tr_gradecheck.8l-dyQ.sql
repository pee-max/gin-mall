create definer = root@localhost trigger tr_gradeCheck
    before update
    on sc
    for each row
begin
   if(new.grade Not Between 0 and 100) then
      set New.grade =Old.grade;
   end if;
end;

