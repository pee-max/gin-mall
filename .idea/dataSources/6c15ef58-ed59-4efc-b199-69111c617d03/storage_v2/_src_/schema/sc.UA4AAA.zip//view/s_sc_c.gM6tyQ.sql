create definer = root@localhost view s_sc_c as
select `s`.`Sno` AS `xh`, `s`.`Sname` AS `xm`, `c`.`Cno` AS `kch`, `c`.`Cname` AS `kcm`, `sc`.`sc`.`Grade` AS `cj`
from ((`sc`.`student` `s` join `sc`.`course` `c`) join `sc`.`sc`)
where ((`s`.`Sno` = `sc`.`sc`.`Sno`) and (`c`.`Cno` = `sc`.`sc`.`Cno`));

