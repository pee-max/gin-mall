create
    definer = root@localhost procedure getAvg(IN sno1 varchar(5), OUT avg1 float(5, 2))
BEGIN
	 START TRANSACTION;
    select avg(grade) into avg1 from sc 
       where   sno=sno1;  
		  if(  avg1 IS NULL) then
		 	 ROLLBACK;
		 END if;
    -- update student set avgGrade=avg1 
         -- where  sno=sno1; 
     COMMIT;
end;

